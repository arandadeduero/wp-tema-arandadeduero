<?php

/**
 * Aranda de Duero functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Aranda_de_Duero
 */


if ( ! defined( 'ARANDA_DE_DUERO_VERSION' ) ) {
	// Fallback version, only used if an asset file can't be found on disk.
	define( 'ARANDA_DE_DUERO_VERSION', '1.0.0' );
}

if ( ! function_exists( 'aranda_de_duero_asset_version' ) ) :
	/**
	 * Cache-busting version string for a theme asset, based on the file's
	 * own last-modified time instead of a single hardcoded version number
	 * that's easy to forget to bump after editing a file — browsers and
	 * CDNs would otherwise keep serving a stale cached copy after a change.
	 *
	 * @param string      $relative_path Path relative to $base_dir, e.g. '/css/aranda-de-duero.css'.
	 * @param string|null $base_dir Defaults to get_template_directory().
	 * @return string
	 */
	function aranda_de_duero_asset_version( $relative_path, $base_dir = null ) {
		$base_dir = $base_dir ? $base_dir : get_template_directory();
		$file     = $base_dir . $relative_path;

		return file_exists( $file ) ? (string) filemtime( $file ) : ARANDA_DE_DUERO_VERSION;
	}
endif;

if ( ! function_exists( 'aranda_de_duero_setup' ) ) :
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support for post thumbnails.
	 */
	function aranda_de_duero_setup() {
		/*
		 * Make theme available for translation.
		 * Translations can be filed in the /languages/ directory.
		 * If you're building a theme based on Aranda de Duero, use a find and replace
		 * to change 'aranda-de-duero' to the name of your theme in all the template files.
		 */
		load_theme_textdomain( 'aranda-de-duero', get_template_directory() . '/languages' );

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		/*
		 * Let WordPress manage the document title.
		 * By adding theme support, we declare that this theme does not use a
		 * hard-coded <title> tag in the document head, and expect WordPress to
		 * provide it for us.
		 */
		add_theme_support( 'title-tag' );

		/*
		 * Enable support for Post Thumbnails on posts and pages.
		 *
		 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		 */
		add_theme_support( 'post-thumbnails' );

		// This theme uses wp_nav_menu() in one location.
		register_nav_menus(
			array(
				'menu-1' => esc_html__( 'Primary', 'aranda-de-duero' ),
			)
		);

		/*
		 * Switch default core markup for search form, comment form, and comments
		 * to output valid HTML5.
		 */
		add_theme_support(
			'html5',
			array(
				'search-form',
				'comment-form',
				'comment-list',
				'gallery',
				'caption',
				'style',
				'script',
			)
		);

		// Set up the WordPress core custom background feature.
		add_theme_support(
			'custom-background',
			apply_filters(
				'aranda_de_duero_custom_background_args',
				array(
					'default-color' => 'ffffff',
					'default-image' => '',
				)
			)
		);

		// Add theme support for selective refresh for widgets.
		add_theme_support( 'customize-selective-refresh-widgets' );

		// Load the theme's own stylesheets inside the block editor (see add_editor_style() calls below).
		add_theme_support( 'editor-styles' );

		// Add default styling for core blocks (buttons, quotes, etc.) when used in page content.
		add_theme_support( 'wp-block-styles' );

		// Allow wide and full alignment for blocks used in page content.
		add_theme_support( 'align-wide' );

		// Make embedded content (YouTube, Twitter, etc.) responsive by default.
		add_theme_support( 'responsive-embeds' );

		/**
		 * Add support for core custom logo.
		 *
		 * @link https://codex.wordpress.org/Theme_Logo
		 */
		add_theme_support(
			'custom-logo',
			array(
				'height'      => 600,
				'width'       => 200,
				'flex-width'  => true,
				'flex-height' => true,
			)
		);
	}
endif;
add_action( 'after_setup_theme', 'aranda_de_duero_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function aranda_de_duero_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'aranda_de_duero_content_width', 640 );
}
add_action( 'after_setup_theme', 'aranda_de_duero_content_width', 0 );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function aranda_de_duero_widgets_init() {
	// All sidebars share the same shape; only the name/id differ.
	$sidebars = array(
		'sidebar-1'            => 'Sidebar',
		'sidebar-villa'        => 'Villa',
		'sidebar-noticias'     => 'Noticias',
		'sidebar-tramites'     => 'Tramites',
		'sidebar-actualidad'   => 'Actualidad',
		'sidebar-servicios'    => 'Servicios',
	);

	foreach ( $sidebars as $sidebar_id => $sidebar_name ) {
		register_sidebar(
			array(
				// Not run through __() on purpose: these are proper-noun area names (not UI copy), and __() requires a literal string argument for translation-string extraction.
				'name'          => esc_html( $sidebar_name ),
				'id'            => $sidebar_id,
				'description'   => esc_html__( 'Add widgets here.', 'aranda-de-duero' ),
				'before_widget' => '<section id="%1$s" class="widget %2$s">',
				'after_widget'  => '</section>',
				'before_title'  => '<h2 class="widget-title">',
				'after_title'   => '</h2>',
			)
		);
	}
}
add_action( 'widgets_init', 'aranda_de_duero_widgets_init' );

/**
 * Enqueue theme scripts and styles.
 *
 * Loads Bootstrap 5, Font Awesome, and custom theme assets with proper
 * dependencies and caching headers.
 *
 * @since 1.0.0
 * @uses wp_enqueue_style()
 * @uses wp_enqueue_script()
 *
 * @return void
 */
function aranda_de_duero_scripts() {
	// Core theme styles
	wp_enqueue_style(
		'aranda-de-duero-style',
		get_stylesheet_uri(),
		array(),
		aranda_de_duero_asset_version( '/style.css', get_stylesheet_directory() ),
		'all'
	);

	// Custom theme styles with CSS variables
	wp_enqueue_style(
		'aranda-de-duero-custom-style',
		get_template_directory_uri() . '/css/aranda-de-duero.css',
		array(),
		aranda_de_duero_asset_version( '/css/aranda-de-duero.css' ),
		'all'
	);

	// RTL support
	wp_style_add_data( 'aranda-de-duero-style', 'rtl', 'replace' );

	// Navigation - deferred loading for better performance
	wp_enqueue_script(
		'aranda-de-duero-navigation',
		get_template_directory_uri() . '/js/navigation.js',
		array(),
		aranda_de_duero_asset_version( '/js/navigation.js' ),
		array(
			'in_footer' => true,
			'strategy'  => 'defer',
		)
	);

	// Fixed header: measures the bars and shrinks the «¿Qué necesitas?» band of the home page while it is stuck.
	wp_enqueue_script(
		'aranda-de-duero-sticky-header',
		get_template_directory_uri() . '/js/sticky-header.js',
		array(),
		aranda_de_duero_asset_version( '/js/sticky-header.js' ),
		array(
			'in_footer' => true,
			'strategy'  => 'defer',
		)
	);

	// Main theme script - deferred for non-critical path
	wp_enqueue_script(
		'aranda-de-duero-script',
		get_template_directory_uri() . '/js/aranda-de-duero.js',
		array(),
		aranda_de_duero_asset_version( '/js/aranda-de-duero.js' ),
		array(
			'in_footer' => true,
			'strategy'  => 'defer',
		)
	);

	// Event poster: pop-up preview with a download button, only on a single event.
	if ( is_singular( 'mc-events' ) ) {
		wp_enqueue_script(
			'aranda-de-duero-event-poster',
			get_template_directory_uri() . '/js/event-poster.js',
			array(),
			aranda_de_duero_asset_version( '/js/event-poster.js' ),
			array(
				'in_footer' => true,
				'strategy'  => 'defer',
			)
		);
		wp_localize_script(
			'aranda-de-duero-event-poster',
			'arandaEventPoster',
			array(
				'zoom'     => __( 'Ampliar el cartel', 'aranda-de-duero' ),
				'download' => __( 'Descargar imagen', 'aranda-de-duero' ),
				'close'    => __( 'Cerrar', 'aranda-de-duero' ),
			)
		);
	}

	// Comment reply for threaded comments
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'aranda_de_duero_scripts' );

/**
 * Enqueue Bootstrap 5 CSS.
 *
 * Loads Bootstrap 5 framework CSS from the theme's local css/ directory.
 * Self-hosted to avoid sending visitor IP addresses to third-party CDNs (GDPR).
 *
 * @since 1.0.0
 * @return void
 */
function aranda_de_duero_bootstrap_css() {
	wp_enqueue_style(
		'bootstrap_css',
		get_template_directory_uri() . '/css/bootstrap.min.css',
		array(),
		'5.3.8',
		'all'
	);
}
add_action( 'wp_enqueue_scripts', 'aranda_de_duero_bootstrap_css' );

/**
 * Customizer colours exposed as CSS custom properties.
 */
require get_template_directory() . '/inc/customizer-css.php';

/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * SVG icon set (replaces Font Awesome).
 */
require get_template_directory() . '/inc/icons.php';

/**
 * Reusable block patterns for content editors.
 */
require get_template_directory() . '/inc/block-patterns.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Open Graph / Twitter Card meta tags.
 */
require get_template_directory() . '/inc/social-meta.php';

/**
 * Front-end performance and privacy tweaks (emoji, Font Awesome plugin).
 */
require get_template_directory() . '/inc/performance.php';

/**
 * Upcoming events (My Calendar), cached.
 */
require get_template_directory() . '/inc/events.php';

/**
 * Home carousel (replaces Smart Slider).
 */
require get_template_directory() . '/inc/home-carousel.php';

/**
 * "Especiales" section of the home (replaces Ajax Load More).
 */
require get_template_directory() . '/inc/especiales.php';

/**
 * Service shortcuts: «Accesos frecuentes» (home) and «Pagos y recibos».
 */
require get_template_directory() . '/inc/services.php';

/**
 * «¿Qué necesitas?»: service finder for the search box and the search results.
 */
require get_template_directory() . '/inc/search.php';

/**
 * «Trámites por situaciones»: procedures grouped by what the visitor is going through.
 */
require get_template_directory() . '/inc/situations.php';

/**
 * «Para ti»: services grouped by who is asking (families, older people, young people, businesses…).
 */
require get_template_directory() . '/inc/audiences.php';

/**
 * Content types and taxonomies (registered here instead of by the Custom Post Type UI plugin).
 */
require get_template_directory() . '/inc/content-types.php';

/**
 * Archives of the "concejalia" and "tema" terms: pagination and notice of historic archives.
 */
require get_template_directory() . '/inc/term-archives.php';

/**
 * Index pages /tema/, /concejalia/ and /tramite/ (a list of what exists, more detail for administrators).
 */
require get_template_directory() . '/inc/term-index.php';

/**
 * General information of a concejalía (concejal, phone, e-mail, location) as term meta.
 */
require get_template_directory() . '/inc/term-contact.php';

/**
 * Left-hand menu of the concejalía and tema archives: the sub-menu «Áreas y servicios» of the main menu.
 */
require get_template_directory() . '/inc/areas-menu.php';

/**
 * Colour contrast helpers and Customizer validation.
 */
require get_template_directory() . '/inc/color-contrast.php';

/**
 * JSON-LD structured data.
 */
require get_template_directory() . '/inc/structured-data.php';

/**
 * Speculation Rules (prefetch/prerender of internal links).
 */
require get_template_directory() . '/inc/speculation-rules.php';

/**
 * E-mail reminders for information that goes out of date (delegations of the concejalías) and who receives them.
 */
require get_template_directory() . '/inc/reminders.php';

/**
 * Duty pharmacies (data/farmacias/<year>.json) and the yearly reminder to load the next calendar.
 */
require get_template_directory() . '/inc/pharmacies.php';

/**
 * Load Jetpack compatibility file.
 */
if ( defined( 'JETPACK__VERSION' ) ) {
	require get_template_directory() . '/inc/jetpack.php';
}



/**
 * Keep the stored custom script unless the current user may post unfiltered HTML.
 *
 * @param string $value Submitted script.
 * @return string
 */
function aranda_de_duero_sanitize_custom_script( $value ) {
	if ( current_user_can( 'unfiltered_html' ) ) {
		return (string) $value;
	}

	return (string) get_theme_mod( 'aranda_de_duero_custom_script', '' );
}

/**
 * Customizer options
 */
function aranda_de_duero_customizer_settings( $wp_customize ) {

	$wp_customize->add_section(
		'aranda_de_duero_options',
		array(
			'title'       => 'Aranda de Duero',
			'description' => 'Opciones específicas para el tema Aranda de Duero',
			'priority'    => 120,
		)
	);
	// Color controls: all share the same setting/control shape, differing
	// only in slug, label and default value.
	$color_defaults = aranda_de_duero_customizer_color_defaults();
	$color_settings = array(
		'aranda_de_duero_background_color' => array(
			'label'   => 'Color de fondo',
			'default' => $color_defaults['aranda_de_duero_background_color'],
		),
		'aranda_de_duero_header_text_color' => array(
			'label'   => 'Color de los encabezados',
			'default' => $color_defaults['aranda_de_duero_header_text_color'],
		),
		'aranda_de_duero_text_color' => array(
			'label'   => 'Color del texto',
			'default' => $color_defaults['aranda_de_duero_text_color'],
		),
		'aranda_de_duero_link_color' => array(
			'label'   => 'Color de los enlaces',
			'default' => $color_defaults['aranda_de_duero_link_color'],
		),
		'aranda_de_duero_main_section_background' => array(
			'label'   => 'Color de fondo de las secciones principales en el home',
			'default' => $color_defaults['aranda_de_duero_main_section_background'],
		),
		'aranda_de_duero_main_section_text_color' => array(
			'label'   => 'Color de texto de las secciones principales en el home',
			'default' => $color_defaults['aranda_de_duero_main_section_text_color'],
		),
	);

	foreach ( $color_settings as $setting_id => $setting_args ) {
		$wp_customize->add_setting(
			$setting_id,
			array(
				'default'           => $setting_args['default'],
				'transport'         => 'refresh',
				'sanitize_callback' => 'sanitize_hex_color',
				'validate_callback' => 'aranda_de_duero_validate_color_contrast',
			)
		);
		$wp_customize->add_control(
			new WP_Customize_Color_Control(
				$wp_customize,
				$setting_id,
				array(
					'label'    => $setting_args['label'],
					'section'  => 'aranda_de_duero_options',
					'settings' => $setting_id,
				)
			)
		);
	}

	// Raw JS runs on every page, so only users allowed to post unfiltered HTML
	// (not e.g. a multisite site admin) may edit it, and anyone else keeps the stored value.
	$wp_customize->add_setting(
		'aranda_de_duero_custom_script',
		array(
			'capability'        => 'unfiltered_html',
			'sanitize_callback' => 'aranda_de_duero_sanitize_custom_script',
		)
	);
	$wp_customize->add_control(
		'aranda_de_duero_custom_script',
		array(
			'type'    => 'textarea',
			'id'      => 'aranda_de_duero_custom_script',
			'label'   => 'Javascript personalizado',
			'section' => 'aranda_de_duero_options',
		)
	);
	// add a setting for Default header image
	$wp_customize->add_setting( 'aranda_de_duero_default_header_image', array( 'sanitize_callback' => 'absint' ) );
	// Add a control for Default header image
	$wp_customize->add_control(
		new WP_Customize_Media_Control(
			$wp_customize,
			'aranda_de_duero_default_header_image',
			array(
				'section'   => 'aranda_de_duero_options',
				'label'     => 'Imagen por defecto para las cabeceras de página',
				'mime_type' => 'image',
			)
		)
	);

	// add a setting for the default social sharing (Open Graph) image
	$wp_customize->add_setting( 'aranda_de_duero_social_share_image', array( 'sanitize_callback' => 'absint' ) );
	// Add a control for the default social sharing (Open Graph) image
	$wp_customize->add_control(
		new WP_Customize_Media_Control(
			$wp_customize,
			'aranda_de_duero_social_share_image',
			array(
				'section'     => 'aranda_de_duero_options',
				'label'       => 'Imagen por defecto para compartir en redes sociales',
				'description' => 'Se usa cuando una página o noticia no tiene imagen destacada. Tamaño recomendado: 1200x630 px.',
				'mime_type'   => 'image',
			)
		)
	);

	// Internal reporting channel (Ley 2/2023): shows a footer link once filled in.
	$wp_customize->add_setting(
		'aranda_de_duero_whistleblower_url',
		array(
			'default'           => '',
			'sanitize_callback' => 'esc_url_raw',
		)
	);
	$wp_customize->add_control(
		'aranda_de_duero_whistleblower_url',
		array(
			'type'        => 'url',
			'label'       => 'Canal interno de información (URL)',
			'description' => 'Ley 2/2023, de protección del informante. Si se rellena, aparece un enlace «Canal de información» en el pie de todas las páginas. Déjalo vacío hasta que el canal exista.',
			'section'     => 'aranda_de_duero_options',
		)
	);

	// CheckBox Banner Plenos
	$wp_customize->add_setting(
		'aranda_de_duero_show_banner',
		array(
			'default'           => '',
			'sanitize_callback' => 'rest_sanitize_boolean',
		)
	);

	// add control
	$wp_customize->add_control(
		'aranda_de_duero_show_banner_checkbox',
		array(
			'label'                               => 'Mostrar banner de plenos en la home page',
			'type'                                => 'checkbox',
			// this indicates the type of control
										'section' => 'aranda_de_duero_options',
			'settings'                            => 'aranda_de_duero_show_banner',
		)
	);

	// Texto Banner Plenos
	$wp_customize->add_setting(
		'aranda_de_duero_show_banner_text',
		array(
			'default'           => '',
			'sanitize_callback' => 'sanitize_text_field',
		)
	);

	// add control
	$wp_customize->add_control(
		'aranda_de_duero_show_banner_text',
		array(
			'label'                               => 'Texto a mostrar en el banner de plenos en la home page',
			'type'                                => 'text',
			// this indicates the type of control
										'section' => 'aranda_de_duero_options',
			'settings'                            => 'aranda_de_duero_show_banner_text',
		)
	);
}
add_action( 'customize_register', 'aranda_de_duero_customizer_settings' );

/**
 * Prints the customizer colours as CSS custom properties on :root.
 */
function aranda_de_duero_customize_css() {
	?>
	<style>
		:root {
		<?php foreach ( aranda_de_duero_customizer_css_variables() as $property => $value ) : ?>
			<?php echo esc_attr( $property ); ?>: <?php echo esc_attr( $value ); ?>;
		<?php endforeach; ?>
		}
	</style>
	<?php
}
add_action( 'wp_head', 'aranda_de_duero_customize_css' );

/**
 * Preload the main web font so text doesn't wait for the CSS to be parsed first.
 */
function aranda_de_duero_preload_font() {
	printf(
		'<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n",
		esc_url( get_template_directory_uri() . '/css/fonts/outfit-variable-latin.woff2' )
	);
}
add_action( 'wp_head', 'aranda_de_duero_preload_font', 2 );

/**
 * Remove legacy <head> output nobody needs: generator version (leaks the WordPress
 * version), Windows Live Writer manifest and Really Simple Discovery link.
 */
remove_action( 'wp_head', 'wp_generator' );
remove_action( 'wp_head', 'wlwmanifest_link' );
remove_action( 'wp_head', 'rsd_link' );

/**
 * Output custom inline JavaScript for theme features.
 *
 * Includes:
 * - Custom user scripts from theme customizer
 * - Video context menu protection
 *
 * @since 1.0.0
 * @return void
 */
function aranda_de_duero_customize_js() {
	?>
	<script>
		document.addEventListener('DOMContentLoaded', function() {
			'use strict';

			// User custom script from theme customizer
			<?php
			// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- intentionally raw: an admin-authored JS snippet meant to run verbatim, not text content.
			echo get_theme_mod( 'aranda_de_duero_custom_script' );
			?>

			// Prevent right-click context menu on video elements
			document.querySelectorAll('video').forEach(video => {
				video.addEventListener('loadeddata', () => {
					video.addEventListener('contextmenu', (e) => {
						e.preventDefault();
						return false;
					});
				});
			});
		});
	</script>
	<?php
}
add_action( 'wp_footer', 'aranda_de_duero_customize_js' );

/**
 * Query a post type for the theme's listings.
 *
 * @param string      $type       Post type.
 * @param string|null $order      Field to order by.
 * @param string|null $order_way  ASC or DESC.
 * @param int|string|null $limit   Posts per page.
 * @param bool        $paginated  Pass false when the result isn't paginated, which skips
 *                                the extra SELECT FOUND_ROWS()/COUNT query.
 * @param array<string, mixed> $extra_args Extra WP_Query arguments, e.g. post_status.
 * @return WP_Query
 */
function aranda_de_duero_content( $type, $order = null, $order_way = null, $limit = null, $paginated = true, $extra_args = array() ) {
	$paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;
	$args  = array(
		'post_type'      => $type,
		'order'          => $order_way,
		'orderby'        => $order,
		'posts_per_page' => $limit,
		'paged'          => $paged,
		'no_found_rows'  => ! $paginated,
	);
	return new WP_Query( array_merge( $args, $extra_args ) );
}

function aranda_de_duero_temas( $slug ) {
	$paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;
	$args  = array(
		'post_type'      => 'post',
		'order'          => 'desc',
		'orderby'        => 'date',
		'posts_per_page' => 25,
		'paged'          => $paged,
		'tax_query'      => array(
			array(
				'taxonomy' => 'tema',
				'field'    => 'slug',
				'terms'    => $slug,
			),
		),
	);
	return new WP_Query( $args );
}

function aranda_de_duero_concejalias( $slug ) {
	$paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;
	$args  = array(
		'post_type'      => 'post',
		'order'          => 'desc',
		'orderby'        => 'date',
		'posts_per_page' => 25,
		'paged'          => $paged,
		'tax_query'      => array(
			array(
				'taxonomy' => 'concejalia',
				'field'    => 'slug',
				'terms'    => $slug,
			),
		),
	);
	return new WP_Query( $args );
}

/**
 * Registers an editor stylesheet for the theme.
 */
function aranda_de_duero_register_editor_stylesheet() {
	add_editor_style( 'css/aranda-de-duero.css' );
	add_editor_style( 'css/bootstrap.min.css' );
}
add_action( 'admin_init', 'aranda_de_duero_register_editor_stylesheet' );


/**
 * Check if a post is older than 2 years
 *
 * @return bool True if the post is more than 2 years old, false otherwise
 */
if ( ! function_exists( 'aranda_de_duero_is_post_old' ) ) {
	function aranda_de_duero_is_post_old() {
		$post_date = get_the_date( 'U' );
		// phpcs:ignore WordPress.DateTime.CurrentTimeTimestamp.Requested -- intentional: get_the_date('U') is likewise a site-local-time value read as a timestamp, so the two stay consistent with each other; swapping to time()/gmdate() here would introduce a timezone-offset mismatch instead of fixing one.
		$current_date         = current_time( 'U' );
		$two_years_in_seconds = 2 * 365.25 * 24 * 60 * 60;

		return ( $current_date - $post_date ) > $two_years_in_seconds;
	}
}

/**
 * Display old post disclaimer
 *
 * @return void
 */
if ( ! function_exists( 'aranda_de_duero_old_post_disclaimer' ) ) {
	function aranda_de_duero_old_post_disclaimer() {
		if ( aranda_de_duero_is_post_old() ) {
			?>
			<div class="old-post-disclaimer alert alert-warning d-flex align-items-center mt-3 mb-3" role="alert">
				<span class="mr-3 old-post-disclaimer-icon">
					<?php
					// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- aranda_de_duero_icon() returns SVG markup already sanitized by the WP 7.1 SVG Icon API (see inc/icons.php).
					echo aranda_de_duero_icon( 'aranda-de-duero/triangle-exclamation', array( 'size' => 21 ) );
					?>
				</span>
				<div>
					<strong><?php esc_html_e( 'Contenido antiguo', 'aranda-de-duero' ); ?>:</strong>
					<?php esc_html_e( 'Este contenido tiene más de 2 años. La información puede estar desactualizada.', 'aranda-de-duero' ); ?>
				</div>
			</div>
			<?php
		}
	}
}
