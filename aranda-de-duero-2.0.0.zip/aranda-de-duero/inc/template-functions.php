<?php
defined( 'ABSPATH' ) || exit;

/**
 * Functions which enhance the theme by hooking into WordPress
 *
 * @package Aranda_de_Duero
 */

/**
 * Adds custom classes to the array of body classes.
 *
 * @param array $classes Classes for the body element.
 * @return array
 */
function aranda_de_duero_body_classes( $classes ) {
	// Adds a class of hfeed to non-singular pages.
	if ( ! is_singular() ) {
		$classes[] = 'hfeed';
	}

	// Adds a class of no-sidebar when no sidebar is active for the current context.
	$sidebar_ids = array(
		'sidebar-1',
		'sidebar-villa',
		'sidebar-noticias',
		'sidebar-tramites',
		'sidebar-actualidad',
		'sidebar-servicios',
	);

	$any_active = false;
	foreach ( $sidebar_ids as $sidebar_id ) {
		if ( is_active_sidebar( $sidebar_id ) ) {
			$any_active = true;
			break;
		}
	}

	if ( ! $any_active ) {
		$classes[] = 'no-sidebar';
	}

	return $classes;
}
add_filter( 'body_class', 'aranda_de_duero_body_classes' );

/**
 * Add a pingback url auto-discovery header for single posts, pages, or attachments.
 */
function aranda_de_duero_pingback_header() {
	if ( is_singular() && pings_open() ) {
		printf( '<link rel="pingback" href="%s">', esc_url( get_bloginfo( 'pingback_url' ) ) );
	}
}
add_action( 'wp_head', 'aranda_de_duero_pingback_header' );

/**
 * Text announced to screen readers for links that open in a new tab.
 *
 * @return string
 */
function aranda_de_duero_new_tab_text() {
	return __( '(se abre en una nueva pestaña)', 'aranda-de-duero' );
}

/**
 * Print a visually hidden notice for links that open in a new tab (WCAG 3.2.5 / G201).
 */
function aranda_de_duero_the_new_tab_notice() {
	echo '<span class="screen-reader-text"> ' . esc_html( aranda_de_duero_new_tab_text() ) . '</span>';
}

/**
 * My Calendar widgets that list events (not the calendar itself).
 *
 * @return string[] Widget id bases.
 */
function aranda_de_duero_events_list_widgets() {
	return array(
		'my_calendar_upcoming_widget',
		'my_calendar_today_widget',
	);
}

/**
 * Don't print event-list widgets in sidebars.
 *
 * Upcoming events are shown only on the home page (its agenda section, see
 * page-home.php) and the calendar lives on the Agenda page content. Editors had
 * the "Upcoming events" widget in the Ayuntamiento sidebar, so it appeared on
 * every page using that template. Hiding it at render time leaves the saved
 * widget settings untouched and doesn't affect the Widgets admin screen.
 *
 * Return true from the `aranda_de_duero_show_events_widgets` filter to show them.
 *
 * @param array<string, mixed>|false $instance Widget settings.
 * @param WP_Widget                  $widget   Widget being displayed.
 * @return array<string, mixed>|false False stops the widget from being printed.
 */
function aranda_de_duero_hide_events_widgets( $instance, $widget ) {
	if ( ! in_array( $widget->id_base, aranda_de_duero_events_list_widgets(), true ) ) {
		return $instance;
	}

	return apply_filters( 'aranda_de_duero_show_events_widgets', false ) ? $instance : false;
}
add_filter( 'widget_display_callback', 'aranda_de_duero_hide_events_widgets', 10, 2 );

/**
 * Give menu links without a URL an href so keyboard users can reach them.
 *
 * A custom-link menu item with an empty URL (such as a section header that only opens
 * a submenu) prints an <a> with no href, which browsers don't make focusable. Other
 * header items already use "#", so this just makes the rest consistent.
 *
 * @param array<string, string> $atts Link attributes.
 * @return array<string, string>
 */
function aranda_de_duero_menu_link_href( $atts ) {
	if ( empty( $atts['href'] ) ) {
		$atts['href'] = '#';
	}

	return $atts;
}
add_filter( 'nav_menu_link_attributes', 'aranda_de_duero_menu_link_href' );

/**
 * Contact data shown in the top bar of the header and in the footer, so both always agree.
 *
 * @return array{phone: string, phone_href: string, hours: string, appointment_url: string, transparency_url: string, sede_url: string}
 */
function aranda_de_duero_contact_info() {
	$info = array(
		'phone'            => '947 500 100',
		'phone_href'       => 'tel:947500100',
		'hours'            => 'Lunes a Viernes: 8:30 - 14:30',
		'appointment_url'  => 'https://citaprevia.arandadeduero.es/',
		'transparency_url' => 'https://transparencia.arandadeduero.es/',
		'sede_url'         => 'https://sede.arandadeduero.es/',
	);

	return apply_filters( 'aranda_de_duero_contact_info', $info );
}

/**
 * URL of the internal reporting channel (Ley 2/2023), or '' if none is configured.
 *
 * The link in the footer only appears once an editor sets the URL in the Customizer, so
 * the site never points to a page that doesn't exist yet.
 *
 * @return string
 */
function aranda_de_duero_whistleblower_url() {
	return esc_url_raw( (string) get_theme_mod( 'aranda_de_duero_whistleblower_url', '' ) );
}

/**
 * Spanish for the My Calendar strings the plugin still ships in English.
 *
 * Only strings with no translation yet are touched, so a future translation from the plugin wins.
 *
 * @param string $translation Translated text.
 * @param string $text        Original text.
 * @return string
 */
function aranda_de_duero_my_calendar_strings( $translation, $text ) {
	$overrides = array(
		'Clear Filters' => 'Quitar filtros',
	);

	if ( $translation === $text && isset( $overrides[ $text ] ) ) {
		return $overrides[ $text ];
	}

	return $translation;
}
add_filter( 'gettext_my-calendar', 'aranda_de_duero_my_calendar_strings', 10, 2 );

/**
 * Twelve entries per page in archives (three cards per row), instead of the global reading setting.
 *
 * @param WP_Query $query The query being built.
 */
function aranda_de_duero_archive_page_size( $query ) {
	if ( ! is_admin() && $query->is_main_query() && $query->is_archive() ) {
		$query->set( 'posts_per_page', 12 );
	}
}
add_action( 'pre_get_posts', 'aranda_de_duero_archive_page_size' );

/**
 * Permalink of a published page by its slug (path), or '' when there is no such page.
 *
 * Pages are found by slug, not by title: an editor can retitle a page without breaking the links that point to it.
 *
 * @param string $path Slug or path of the page, as in get_page_by_path().
 * @return string
 */
function aranda_de_duero_page_url( $path ) {
	$page = get_page_by_path( $path );

	return ( $page instanceof WP_Post && 'publish' === $page->post_status ) ? (string) get_permalink( $page ) : '';
}

/**
 * Value of an Advanced Custom Fields field, or '' when the plugin is not active.
 *
 * ACF is a plugin: calling get_field() while it is deactivated is a fatal error on every page that reads a field.
 *
 * @param string $name   Field name.
 * @param mixed  $source Post, term or ACF object id; the current post when omitted.
 * @return mixed
 */
function aranda_de_duero_field( $name, $source = false ) {
	if ( ! function_exists( 'get_field' ) ) {
		return '';
	}

	return get_field( $name, $source );
}
