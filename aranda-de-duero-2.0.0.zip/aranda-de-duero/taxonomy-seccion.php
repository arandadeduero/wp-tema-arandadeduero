<?php
/**
 *
 * Página para mostrar la sección Sección
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Aranda_de_Duero
 */

get_header();
?>

	<div class="container mt-4">
		<div class="row">
			<div class="col-lg-3 pt-4">
				<?php dynamic_sidebar( 'Seccion' ); ?>
			</div>
			<div class="col-lg-9">
				<main id="primary" class="site-main">

					<?php
					get_template_part(
						'template-parts/term-heading',
						null,
						array(
							'term'   => get_queried_object(),
							'kicker' => __( 'Sección', 'aranda-de-duero' ),
						)
					);

					while ( have_posts() ) :
						the_post();

						get_template_part( 'template-parts/content', 'page-notitle' );

						// If comments are open or we have at least one comment, load up the comment template.
						if ( comments_open() || get_comments_number() ) :
							comments_template();
						endif;

					endwhile; // End of the loop.
					?>

				</main><!-- #main -->
			</div>
			
		</div>
	</div>

<?php

get_footer();
