<?php
defined( 'ABSPATH' ) || exit;

/**
 * Template part for displaying results in search pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Aranda_de_Duero
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<header class="entry-header">
		<?php
		the_title( sprintf( '<h3 class="h4 entry-title text-blue"><a class="search-result-title-link" href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h3>' );
		?>

		<?php if ( 'post' === get_post_type() ) : ?>
		<div class="entry-meta">
		</div><!-- .entry-meta -->
		<?php endif; ?>
	</header><!-- .entry-header -->

	<div class="row">
		<div class="col-12">
			<div class="entry-summary">
				<?php
					the_excerpt();
				?>
			</div>
		</div><!-- .entry-summary -->
	</div>

	<footer class="search-entry-footer">
		<?php aranda_de_duero_entry_search_footer(); ?>
	</footer><!-- .entry-footer -->
</article><!-- #post-<?php the_ID(); ?> -->
