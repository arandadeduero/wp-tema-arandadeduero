<?php
/**
 * Template part for displaying tramites
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Aranda_de_Duero
 */

?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<header class="entry-header">
		<?php

			the_title( '<h1 class="entry-title h4"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h1>' );

		// Same notice as the news: a procedure published more than 2 years ago may be out of date.
		aranda_de_duero_old_post_disclaimer();

		if ( 'post' === get_post_type() ) :
			?>
			<div class="entry-meta">
				<?php
				aranda_de_duero_posted_on();
				aranda_de_duero_posted_by();
				?>
			</div><!-- .entry-meta -->
		<?php endif; ?>
	</header><!-- .entry-header -->

	<?php aranda_de_duero_post_thumbnail(); ?>

	<div class="entry-content">
		<!-- Taxonomias  -->
		<?php
			$concejalias = wp_get_post_terms( $post->ID, 'concejalia' );
			$categorias  = wp_get_post_terms( $post->ID, 'categoria_tramite' );
		?>
		<table class="table table-responsive-md table-striped">
			<tbody>
				<tr>
					<td><strong><?php esc_html_e( 'Fecha', 'aranda-de-duero' ); ?></strong></td>
					<td> <?php echo get_the_date(); ?></td>
				</tr>
				<tr>
					<td><strong><?php esc_html_e( 'Concejalía', 'aranda-de-duero' ); ?>: </strong></td>
					<td>
					<?php
					foreach ( $concejalias as $concejalia ) {
							echo esc_html( $concejalia->name );
					}
					?>
					</td>
				</tr>
				<tr>
					<td><strong><?php esc_html_e( 'Categoría', 'aranda-de-duero' ); ?></strong></td>
					<td>
						<?php
						foreach ( $categorias as $categoria ) {
								echo esc_html( $categoria->name );
						}
						?>
					</td>
				</tr>
				<tr>
					<td><strong><?php esc_html_e( 'Dirigido a', 'aranda-de-duero' ); ?> </strong></td>
					<td><?php echo wp_kses_post( aranda_de_duero_field( 'tramite_dirigido' ) ); ?></td>
				</tr>
				<tr>
					<td><strong><?php esc_html_e( 'Gestor', 'aranda-de-duero' ); ?></strong></td>
					<td><?php echo wp_kses_post( aranda_de_duero_field( 'tramite_gestor' ) ); ?></td>
				</tr>
				<tr>
					<td><strong><?php esc_html_e( 'Normativa', 'aranda-de-duero' ); ?></strong></td>
					<td><?php echo wp_kses_post( aranda_de_duero_field( 'tramite_normativa' ) ); ?></td>
				</tr>
				<tr>
					<td><strong><?php esc_html_e( 'Forma de pago', 'aranda-de-duero' ); ?> </strong></td>
					<td><?php echo wp_kses_post( aranda_de_duero_field( 'tramite_pago' ) ); ?></td>
				</tr>
				<tr>
					<td><strong><?php esc_html_e( 'Descripción', 'aranda-de-duero' ); ?> </strong></td>
					<td>
						<?php
						the_content(
							sprintf(
								wp_kses(
									/* translators: %s: Name of current post. Only visible to screen readers */
									__( 'Continue reading<span class="screen-reader-text"> "%s"</span>', 'aranda-de-duero' ),
									array(
										'span' => array(
											'class' => array(),
										),
									)
								),
								wp_kses_post( get_the_title() )
							)
						);
						?>
					</td>
				</tr>
				<tr>
					<td><strong><?php esc_html_e( 'Procedimiento', 'aranda-de-duero' ); ?> </strong></td>
					<td><?php echo wp_kses_post( aranda_de_duero_field( 'tramite_procedimiento' ) ); ?></td>
				</tr>
				<tr>
					<td><strong><?php esc_html_e( 'Fichero adjunto', 'aranda-de-duero' ); ?></strong></td>
					<td><a class="text-dark" href="<?php echo esc_url( aranda_de_duero_field( 'tramite_fichero' ) ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Descargar', 'aranda-de-duero' ); ?><?php aranda_de_duero_the_new_tab_notice(); ?></a></td>
				</tr>
			</tbody>
		</table>
		<?php
		wp_link_pages(
			array(
				'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'aranda-de-duero' ),
				'after'  => '</div>',
			)
		);
		?>
	</div><!-- .entry-content -->

	<footer class="entry-footer">
		<?php aranda_de_duero_entry_footer(); ?>
	</footer><!-- .entry-footer -->
</article><!-- #post-<?php the_ID(); ?> -->
